import keras 
from keras import layers

def load_dataset():  # Define a function to load and preprocess the MNIST dataset  
    num_classes = 10  # Number of classes in the dataset
    (X_train, Y_train), (X_test, Y_test) = keras.datasets.mnist.load_data()  # Load the MNIST dataset
    x_train = X_train.reshape(60000, -1)  # Reshape training data
    x_test = X_test.reshape(10000, -1)  # Reshape test data
    x_train = x_train.astype('float32') / 255.0  # Normalize training data
    x_test = x_test.astype('float32') / 255.0  # Normalize test data
    y_train = keras.utils.to_categorical(Y_train, num_classes)  # Convert training labels to one-hot encoding
    y_test = keras.utils.to_categorical(Y_test, num_classes)  # Convert test labels to one-hot encoding

    return x_train, y_train, x_test, y_test  # Return preprocessed dataset

def train_model():  # Define a function to build and train the neural network model
    x_train, y_train, x_test, y_test = load_dataset()  # Load dataset
    model = keras.Sequential()  # Create a sequential model
    model.add(layers.Dense(256, activation='relu', input_shape=(784,)))  # Add a dense layer with ReLU activation
    model.add(layers.Dense(128, activation='relu'))  # Add another dense layer with ReLU activation
    model.add(layers.Dense(10, activation='softmax'))  # Add a dense layer with softmax activation for output
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])  # Compile the model
    history = model.fit(x_train, y_train, epochs=15, validation_data=(x_test, y_test))  # Train the model
    model.save("mnist_model.keras")  # Save the trained model

if __name__ == "__main__":  # If this script is executed directly
    train_model()  # Call the train_model function to train the neural network model
