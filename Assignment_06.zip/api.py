from fastapi import FastAPI, File, UploadFile
from fastapi.responses import JSONResponse
from fastapi.requests import Request
from utils import load_model, predict_digit, format_image
from PIL import Image
import uvicorn
import sys

app = FastAPI()  # Create a FastAPI app instance

@app.post("/predict")  # Define a route for handling POST requests to '/predict'
async def predict(request: Request, file: UploadFile = File(...)):  # Define a function to handle the POST request
    image = Image.open(file.file)  # Open the uploaded image file using PIL
    data_point = format_image(image)  # Format the image data
    model_path = request.app.state.model_path  # Get the model path from app state
    model = load_model(model_path)  # Load the machine learning model
    digit = predict_digit(model, data_point)  # Predict the digit using the model
    return JSONResponse(content={"digit": digit}, media_type="application/json")  # Return the predicted digit as JSON response

if __name__ == "__main__":  # If this script is executed directly

    model_path = sys.argv[1]  # Get the path to the model file from command line arguments
    app.state.model_path = model_path  # Set the model path in app state

    uvicorn.run(app, host="127.0.0.1", port=8000)  # Run the FastAPI app on localhost with port 8000




