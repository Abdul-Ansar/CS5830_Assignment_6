import keras  
import numpy as np 
from PIL import Image  

def load_model(path: str) -> keras.Sequential:  # Define a function to load a Keras model
    return keras.models.load_model(path)  # Load the Keras model from the specified path

def predict_digit(model: keras.Sequential, data_point: list) -> str:  # Define a function to predict the digit from an image
    data_point = np.array(data_point).reshape((1, 784))  # Reshape the input data point
    prediction = model.predict(data_point)  # Make a prediction using the model
    digit = np.argmax(prediction)  # Get the index of the maximum predicted value
    return str(digit)  # Return the predicted digit as a string

def format_image(image: Image) -> list:  # Define a function to format an image for prediction
    image = image.resize((28, 28))  # Resize the image to 28x28 pixels
    image = image.convert('L')  # Convert the image to grayscale
    data_point = [pixel / 255.0 for pixel in list(image.getdata())]  # Normalize pixel values
    return data_point  # Return the formatted image data as a list
